<?php
// Khởi động session
session_start();

// Kiểm tra nếu đã khởi động session
if (isset($_SESSION)) {
    // Xóa tất cả session variables
    session_unset();

    // Hủy session
    session_destroy();
}

// Redirect về trang đăng nhập hoặc trang chủ
echo "đăng xuất thành công";
header('Location: formdangnhap');
exit(); // Dừng script sau khi chuyển hướng
?>
